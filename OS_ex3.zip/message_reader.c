/*
 * message_reader.c
 *
 *  Created on: 16 ���� 2019
 *      Author: ����
 */
#include "message_slot.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>

/*
  Command line arguments:
� argv[1]: message slot file path.
� argv[2]: the target message channel id. Assume a non-negative integer.
 */
int main(int argc, char** argv){

	int fd;
	int length;
	char buffer[BUF_LEN];
	if (argc!= 3){
		perror("Invalid number of arguments!\n");
		exit(1);
	}
    fd= open(argv[1], O_RDONLY);
	if (fd <0){
	    perror("Can't open device file: ");
	    exit(1);
	}
    if((ioctl(fd, MSG_SLOT_CHANNEL, atoi(argv[2])))<0){
		perror("Error in ioctl: ");
		exit(1);
	}
	length= read(fd, buffer, BUF_LEN);
	if ((length)<0){
	    perror("Error in read: ");
	    exit(1);
	}
	if ((close(fd))<0){
		perror("Error in close: ");
		exit(1);
	}
	if((write(STDOUT_FILENO, buffer,length))<0){
		 perror("Error in printing: ");
		 exit(1);
	}
 exit(0);
}




