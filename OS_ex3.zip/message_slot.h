/*
 * message_slot.h
 *
 *  Created on: 16 ���� 2019
 *      Author: ����
 */

#ifndef MESSAGE_SLOT_H_
#define MESSAGE_SLOT_H_
#include <linux/ioctl.h>


#define BUF_LEN 128
#define MAJOR_NUM 240
#define MAX_NUM_OF_DF 256
#define MSG_SLOT_CHANNEL _IO(MAJOR_NUM, 1)
#define DEVICE_RANGE_NAME "message_slot"
#define DEVICE_FILE_NAME "simple_message_slot_dev"
#define SUCCESS 0

#endif
