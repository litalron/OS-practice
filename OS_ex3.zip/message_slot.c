#undef __KERNEL__
#define __KERNEL__
#undef MODULE
#define MODULE

#include "message_slot.h"
#include <linux/ioctl.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/string.h>
#include <linux/version.h>

MODULE_LICENSE("GPL");

typedef struct message_channel_list {
	struct message_channel_list *next;
	unsigned int channel_id;
	char buffer[BUF_LEN];
	int message_len;
} message_channel_list;

static message_channel_list *message_slot_list[MAX_NUM_OF_DF];

static message_channel_list* search(message_channel_list* head, unsigned int channel_id) {

	if (head==NULL)
		return NULL;
	while (head != NULL){
		if (head->channel_id==channel_id)
			break;
		head=head->next;
	}
	return head;
}

//================== DEVICE FUNCTIONS ===========================
static int device_open( struct inode* inode, struct file*  file){

	if (! file->private_data) {
		file->private_data =(void*) 0;
	}
	return SUCCESS;
}

//---------------------------------------------------------------
static int device_release( struct inode* inode,
                           struct file*  file){
	return SUCCESS;
}

//---------------------------------------------------------------

static ssize_t device_read( struct file* file, char __user* buffer, size_t length, loff_t* offset ){

	int i;
	int minor_number = iminor(file_inode(file));
	int active_channel = (long)(file->private_data);
	message_channel_list* head = message_slot_list[minor_number];
	if (active_channel <=0) {
		printk( KERN_ERR "Read failed! No channel has been set\n");
		return -EINVAL;
	}
	head = search(head, active_channel);
	if (head == NULL){
		printk( KERN_ERR "Read failed! no message on channel\n");
		return -EWOULDBLOCK;
	}
	if (length < head->message_len){
		printk( KERN_ERR "Read failed! provided user buffer is too small\n");
		return -ENOSPC;
	}
	for (i=0; i < head->message_len; i++){
		if ((put_user(head->buffer[i], &buffer[i])) != 0) {
			printk( KERN_ERR "Error in put_user\n");
			return -EFAULT;
		}
	}
	return i;
}


//--------------------------------------------------------------------------------

static ssize_t device_write( struct file*       file,
        const char __user* buffer,
        size_t             length,
        loff_t*            offset){
	int i;
	int minor_number = iminor(file_inode(file));
	int active_channel = (long) (file->private_data);
	message_channel_list* head = message_slot_list[minor_number];
	if (active_channel == 0) {
		printk( KERN_ERR "Write failed! No channel has been set\n");
		return -EINVAL;
	}
	if (length== 0 || length> BUF_LEN){
			printk( KERN_ERR "Write failed! Message length invalid\n");
			return -EMSGSIZE;
	}
	head = search(head, active_channel);
	if (head ==NULL){
		head =(message_channel_list *) kmalloc(sizeof(message_channel_list), GFP_KERNEL);
		if (head==NULL){
			printk( KERN_ERR "Memory allocation of message_slot failed!\n");
			return -ENOMEM;
		}
		head -> next =  message_slot_list[minor_number];
		head -> channel_id = active_channel;
		head -> message_len = 0;
		message_slot_list[minor_number]= head;
	}
	for (i = 0; i < length; i++){
		if ((get_user(head -> buffer[i], &buffer[i])) != 0){
			printk( KERN_ERR "Error in get_user %d\n",i);
			return -EFAULT;
		}
	}
	if (i== length){
		head-> message_len=i;
		return i;
	}
	else{
		printk( KERN_ERR "Error is length \n");
		return -EFAULT;
	}
}


//--------------------------------------------------------------------------
static long device_ioctl( struct   file* file,
                          unsigned int   ioctl_command_id,
                          unsigned long  ioctl_param ){
	if (ioctl_command_id!=MSG_SLOT_CHANNEL ){
	    printk(KERN_ERR "ioctl with an unknown command id %d", ioctl_command_id);
		return -EINVAL;
	}
	if (ioctl_param <=0){
		printk(KERN_ERR "ioctal- invalid channel\n");
		return -EINVAL;
	}
	file->private_data = (void*) ioctl_param;
    return SUCCESS;
}


//==================== DEVICE SETUP =============================

struct file_operations Fops = {
    .owner          = THIS_MODULE,
    .read           = device_read,
    .write          = device_write,
    .open           = device_open,
    .unlocked_ioctl = device_ioctl,
    .release        = device_release,
};

//---------------------------------------------------------------------

static int __init simple_init(void) {
	int rc ;
	rc = register_chrdev( MAJOR_NUM, DEVICE_RANGE_NAME, &Fops );
	/* negative values imply error */
	if( rc < 0 ){
		printk( KERN_ERR "%s registraion failed for %d\n",
				DEVICE_FILE_NAME, MAJOR_NUM);
		return -1;
	}
	return SUCCESS;
}
//------------------------------------------------------------------------
static void free_list_channel(message_channel_list *head){
	message_channel_list *next;
	while (head != NULL){
	            next = head->next;
	            kfree(head);
	            head = next;
	 }
}

static void __exit simple_cleanup(void){
	int i;
	for (i = 0; i < MAX_NUM_OF_DF; i++) {
		free_list_channel(message_slot_list[i]);
	}
	unregister_chrdev(MAJOR_NUM, DEVICE_RANGE_NAME);
}
//------------------------------------------------------------------------
module_init(simple_init);
module_exit(simple_cleanup);

