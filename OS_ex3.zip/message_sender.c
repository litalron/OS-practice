#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stropts.h>
#include <sys/stat.h>
#include "message_slot.h"
/*
 * command line args:
 * argv[1]: message slot file path.
 * argv[2]: the target channel id. Assumes a non-negative integer.
 * argv[3]: the message to pass.
 */
int main(int argc, char** argv){

	int fd;
	if (argc!= 4){
		perror("Invalid number of arguments!\n");
		exit(1);
	}
	fd= open(argv[1], O_WRONLY);
	if (fd <0){
	    perror("Can't open device file: ");
	    exit(1);
	}
	if((ioctl(fd, MSG_SLOT_CHANNEL, atoi(argv[2])))<0){
		perror("Error in ioctl: ");
		exit(1);
	}
	if ((write(fd, argv[3], strlen(argv[3])))<0){
	    perror("Error in write: ");
	    exit(1);
	}
	if ((close(fd))<0){
		perror("Error in close: ");
		exit(1);
	}
	 exit(0);
}


