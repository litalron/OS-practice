/*
 * pfind.c
 *
 *  Created on: 1 ���� 2020
 *      Author: ����
 */
#define _GUN_SOURCE
#define _DEFAULT_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <math.h>
#include <sys/stat.h>

typedef struct queue_node{
	char *path;
	struct queue_node *next;
}queue_node;

queue_node *first;
queue_node *last;
int num_found, num_thread, num_sleep_thread;
int error_thread, finish,len_queue;
char *root_path;
char *search_term;
pthread_mutex_t qlock;
pthread_cond_t not_empty;
pthread_t *threads;

int v=0;



int enqueue(char *dir_path, long tid){

	queue_node* node;
	node =	(queue_node *)malloc(sizeof(queue_node));
	if (node ==NULL){
		fprintf(stderr, "node_queue cannot be allocated\n");
		return -1;
	}

	node->path= (char*)malloc((strlen(dir_path) + 1)*sizeof(char));
	if (node ==NULL){
		fprintf(stderr, "Directory_path cannot be allocated!\n");
		return -1;
		}
	memcpy(node->path, dir_path, strlen(dir_path) + 1);
	node->next= NULL;
	//lock
	if((pthread_mutex_lock(&qlock)) != 0){
		fprintf(stderr, "ERROR locking queue lock");
		return -1;
	}
	if (len_queue==0){
		first = last=node;
	}
	else{
		last->next=node;
		last = last->next;
	}
	len_queue++;

	//signaling that queue is no longer empty
	if((pthread_cond_signal(&not_empty)) != 0){
		fprintf(stderr, "ERROR signaling queue condition variable");
		return -1;
	}
	//unlock
	if((pthread_mutex_unlock(&qlock)) != 0){
		fprintf(stderr, "ERROR unlocking queue lock");
		return -1;
	}
	return 0 ;
}
queue_node* dequeue(long tid){

	queue_node* q= NULL;
	if((pthread_mutex_lock(&qlock)) != 0){
		fprintf(stderr, "ERROR locking queue lock");
		num_sleep_thread++;
		error_thread++;
		pthread_exit(NULL);
	}
	while (len_queue==0){
		num_sleep_thread++;
		if (num_sleep_thread== num_thread){
			return NULL;
		}
		pthread_cond_wait(&not_empty, &qlock);
		if (finish){
			pthread_mutex_unlock(&qlock);
			pthread_exit(NULL);
		}
		num_sleep_thread--;
	}
	q=first;
	if (len_queue==1) first= last = NULL;
	else first = first->next;
	len_queue--;
	pthread_mutex_unlock(&qlock);
	return q;
}

void* flow (void *t){
	long tid = (long) t;
	char* fullPath;
	char* path_q;
	queue_node *q ;
	struct dirent *current_file;
	DIR* dir;
	int length_p, err;
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, 0);

	while (num_sleep_thread< num_thread && (!finish)){
		q = dequeue(tid);
		if(q==NULL){
			finish=1;
			if((pthread_cond_broadcast(&not_empty)) != 0){//wake everyone up
				fprintf(stderr, "ERROR in pthread_cond_broadcast");
				error_thread++;
			}
			pthread_mutex_unlock(&qlock);
			pthread_exit(NULL);
		}
		else{
			path_q = q->path;
			dir = opendir(path_q);
			if (dir == NULL){
				fprintf(stderr, "Could not open current directory.\n");
				error_thread++;
				num_sleep_thread++;
				pthread_exit(NULL);
			}
			while ((current_file = readdir(dir)) != NULL){
				if (current_file->d_type != DT_DIR){// file found
					if (strstr(current_file->d_name, search_term) != NULL){ //the name contains the term
						num_found++;
						printf("%s/%s\n", path_q, current_file->d_name);
					}
				}
				if (current_file->d_type == DT_DIR && strcmp(current_file->d_name,".") && strcmp(current_file->d_name,"..") ) {
					length_p = strlen(path_q) + strlen(current_file->d_name) + 2;
					fullPath = (char*)calloc(length_p, sizeof(char)); //creating name for directory
					if (fullPath==NULL){
						error_thread ++;
						num_sleep_thread++;
						pthread_exit(NULL);
					}
					strcat(strcat(strcat(fullPath, path_q), "/"), current_file->d_name);
					fullPath[length_p-1] = '\0';
					err =enqueue(fullPath, tid);
					if (err == -1){
						fprintf(stderr, "Directory cannot be added!\n");
						num_sleep_thread++;
						error_thread++;
						free(fullPath);
						free(q->path);
						free (q);
						pthread_exit(NULL);
					}
					free(fullPath);
				}
			}
			if (closedir(dir)!= 0){
				free(q->path);
				free (q);
				num_sleep_thread++;
				error_thread++;
				pthread_exit(NULL);
			}
		}
		free(q->path);
		free (q);
	}
	pthread_exit(NULL);
}

void SIGINT_handler(int signum){
	int i;
	for (i = 0; i < num_thread; i++){
		pthread_cancel(threads[i]);
	}
    printf("Search stopped, found %d files\n", num_found);

    exit(0);
}

void prepere( char *argv[]){
	error_thread= num_found= len_queue= num_sleep_thread= finish =0;
	root_path= argv[1];
	if(access(root_path, F_OK) != 0){
		fprintf(stderr, "path is not accessible\n");
		exit(1);
	}
	search_term = argv[2];
	num_thread= atoi(argv[3]);
	threads = (pthread_t *) malloc(sizeof(pthread_t) * num_thread);
	if (threads== NULL){
		fprintf(stderr, "can't allocate threads\n");
		exit(1);
	}
}
int main(int argc, char *argv[]){
	long i;
	int err;
	struct  sigaction  SIG_INT;
	if (argc != 4) {
		fprintf(stderr, "Error: invalid number of arguments");
		exit(1);
	}
	prepere(argv);

	// handling SIGINT
	memset(&SIG_INT, 0, sizeof(struct sigaction));
	SIG_INT.sa_handler = SIGINT_handler;
	SIG_INT.sa_flags = SA_RESTART | SA_SIGINFO;;
	if((sigaction(SIGINT, &SIG_INT, NULL))== -1){
		fprintf(stderr, "ERROR Signal handle registration failed\n");
		exit(1);
	}

	// initialize queue lock
	if((pthread_mutex_init(&qlock, NULL)) != 0) {
		fprintf(stderr, "ERROR in pthread_mutex_init()\n");
	    exit(1);
	}
	// initialize conditional variable
	if((pthread_cond_init (&not_empty, NULL))!= 0){
		fprintf(stderr, "ERROR in pthread_cond_init()\n");
		exit(1);
	}
	// create queue and add root to queue
	err=enqueue(root_path,-1);
	if((err ==-1)|| first==NULL) exit(1);

	//create n threads
	for (i = 0; i < num_thread; i++) {
		if ((pthread_create( &threads[i], NULL, flow, (void*) i))!=0) {
			fprintf(stderr,"error in pthread_create()\n");
			exit(1);
		}
	}

	for (i = 0; i<num_thread; ++i) pthread_join(threads[i], NULL);

	printf("Done searching, found %d files\n", num_found);

	free(threads);
	pthread_cond_destroy(&not_empty);
	pthread_mutex_destroy(&qlock);

	if (error_thread == num_thread){
		exit(1);
	}
	exit(0);
	return 0;
}

